# Icons

Place your extension icons here:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)
- icon128.png (128x128 pixels)

You can create simple icons using online tools like:
- https://www.favicon-generator.org/
- https://www.canva.com/
- Or any image editing software

For now, you can use placeholder images or the extension will work without icons (Chrome will show a default icon).
